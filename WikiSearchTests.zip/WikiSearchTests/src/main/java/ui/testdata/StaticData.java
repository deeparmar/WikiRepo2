package ui.testdata;

import ui.utils.FileUtils;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class StaticData {

    public static String Default_Lang="EN";
    public static String SEARCH_TERM ="Greece"; //This can be read from CSV file also
    public static String DEU_Lang="DE";
    public static String DEU_URL="https://de.wikipedia.org/wiki/Griechenland";
    public static String EN_URL="https://en.wikipedia.org/wiki/";

    public static ArrayList LanguageList() {

        ArrayList expLang = new ArrayList();
        expLang = FileUtils.ReadLangFile();
        return expLang;
    }

}
