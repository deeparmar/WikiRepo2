package ui.controls;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import ui.utils.CommonFunctions;

import java.util.ArrayList;
import java.util.List;

public class DropDown extends BaseElement {

    public DropDown(WebDriver driver)
    {
        super(driver);
    }

    public void select(WebElement element, String valueToSelect)
    {
        if(isElementDisplayed(element))
        {
            Select dropdown = new Select(element);

            if (valueToSelect != null) {
                CommonFunctions.waitForSeconds(1);
                dropdown.selectByVisibleText(valueToSelect);
            }
        }
    }


    public void selectByValue(WebElement element, String valueToSelect)
    {
        if(isElementDisplayed(element))
        {
            Select dropdown = new Select(element);

            if (valueToSelect != null) {
                dropdown.selectByValue(valueToSelect);
            }
        }
    }


    public void selectByIndex(WebElement element, String valueToSelect)
    {

        List<String> items = this.getListOfItems(element);

        if (items.contains(valueToSelect)) {

            for (int i=0; i < items.size(); i++){

                if (items.get(i).equals(valueToSelect)){

                    Select dropdown = new Select(element);
                    dropdown.selectByIndex(i);
                    break;
                }
            }

        }

    }

    public List<String> getListOfItems(WebElement element) {

        List<String> items = new ArrayList<String>();

        if (isElementDisplayed(element))
        {
            Select dropdown = new Select(element);

            List<WebElement> options = dropdown.getOptions();

            for (int i = 0; i < options.size(); i++)
            {
                String itemText = options.get(i).getText();
                System.out.println("-" + itemText + "-");
                items.add(itemText);
            }
        }

        return items;
    }

    public String getSelectedItem(WebElement element)
    {
        String sText = "";

        if(isElementDisplayed(element))
        {
            Select dropdown = new Select(element);

            sText = dropdown.getFirstSelectedOption().getText();
        }

        return sText;
    }
}
