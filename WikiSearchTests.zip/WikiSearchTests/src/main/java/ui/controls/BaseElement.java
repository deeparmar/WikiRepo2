package ui.controls;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import ui.pages.BaseUIPage;


public class BaseElement extends BaseUIPage {

    public BaseElement(WebDriver driver) {

        super(driver);
    }

    public void Click(WebElement element)
    {
        if(isElementDisplayed(element)) {
            element.click();
        }
    }

}
