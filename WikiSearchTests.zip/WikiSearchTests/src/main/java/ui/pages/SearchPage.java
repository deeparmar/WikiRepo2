package ui.pages;

import com.fasterxml.jackson.databind.ser.Serializers;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ui.controls.DropDown;


public class SearchPage extends BaseUIPage {

    public SearchPage(WebDriver driver)
    {
        super(driver);

    }


    @FindBy(id = "searchInput")
    private WebElement searchInput;

    @FindBy(id = "searchLanguage")
    private WebElement searchLanguage;

    @FindBy(css = ".svg-search-icon")
    private WebElement search;



    public void setSearchTerm(String searchText) {
        if(isElementDisplayed(searchInput))
        {
            searchInput.clear();
            searchInput.sendKeys(searchText);
        }
    }


    public void selectSearchLanguage(String searchText) {

        DropDown dropDown = new DropDown(driver);
        dropDown.select(searchLanguage, searchText);
    }

    public <T extends BaseUIPage> T submitSearch()
    {

        this.search.click();
        SearchResultPage searchResultPage = new SearchResultPage(driver);
       searchResultPage.isElementDisplayed(searchResultPage.pageHeading);
        return (T) new SearchResultPage(driver);
    }


}
