package ui.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import ui.utils.CommonFunctions;
import ui.utils.Environment;

public class BaseUIPage {

    public static WebDriver driver;

    private String title;

    public BaseUIPage(WebDriver driver)
    {
        this.driver = driver;

        PageFactory.initElements(driver, this);

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public boolean isElementDisplayed(WebElement elementToCheck)
    {
        return isElementDisplayed(elementToCheck, 5, true);
    }

    public boolean isTextPresent(String searchText){

            boolean found = false;
            if (driver.getPageSource().contains(searchText))
                found = true;

            return found;
    }
    public boolean isElementDisplayed(WebElement elementToCheck, int iTimeToWaitInSeconds, boolean catchException)
    {
        WebDriverWait wait = new WebDriverWait(driver, iTimeToWaitInSeconds);

        try {
            wait.until((ExpectedCondition<Boolean>) wd -> elementToCheck.isDisplayed());
            return true;
        } catch (Exception e) {
            if (catchException == true)
            {
                e.printStackTrace();
            }

            return false;
        }
    }



    public void scrollIntoView(WebElement element){

        JavascriptExecutor je = (JavascriptExecutor) driver;
        je.executeScript("arguments[0].scrollIntoView(true);",element);
    }


    public boolean checkIfPageHasLoaded(WebElement element, String elementExpectedText){

        String elementText = "";
        System.out.println();

        for (int i=0; i<3; i++) {

            boolean elementFound = this.isElementDisplayed(element,Environment.webDriverWaitTime,true);

            if (elementFound){

                elementText = element.getText();
                if (elementText.equals(elementExpectedText))
                {
                    return true;
                }
                else{
                    CommonFunctions.waitForSeconds(1);
                }
            }
        }

        System.out.println("### Did not find page with heading: " + elementExpectedText);
        System.out.println("### Actually found page with heading: " + elementText);

        try {
            throw new AssertionError();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

    public boolean checkIfPageHasLoadedContainsHeading(WebElement element, String elementExpectedText){

        String elementText = "";
        System.out.println();

        for (int i=0; i<3; i++) {

            boolean elementFound = this.isElementDisplayed(element,Environment.webDriverWaitTime,true);

            if (elementFound){

                elementText = element.getText();
                if (elementText.contains(elementExpectedText))
                {
                    return true;
                }
                else{
                    CommonFunctions.waitForSeconds(1);
                }
            }
        }

        try {
            throw new AssertionError();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return false;
    }

}
