package ui.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class SearchResultPage extends BaseUIPage {

    @FindBy(id = "firstHeading")
    public WebElement pageHeading;

    @FindBy(id = "p-lang")
    public WebElement languages;

    @FindBy(css = "a[class='interlanguage-link-target']")
    public List<WebElement> listLanguages;

    @FindBy(xpath = "//a[contains(text(),'Edit links')] ")
    public WebElement editLink;

    public SearchResultPage(WebDriver driver)
    {
        super(driver);

    }

    public boolean isElementDisplayed(WebElement elementToCheck)
    {
        return isElementDisplayed(elementToCheck, 5, true);
    }


}
