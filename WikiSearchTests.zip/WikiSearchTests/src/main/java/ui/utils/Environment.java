package ui.utils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.Properties;


public class Environment {

	public static String environment;
	public static String server;
	public static String appurl;
	public static String dburl;
	public static String dbuser;
	public static String dbpwd;
	public static String apiCreateCaseUrl;
	public static String remoteWebDriverUrl;
	public static int webDriverWaitTime;



	public static Properties getProperties() throws IOException, URISyntaxException {

		environment = "TestEnv";
		String appEnv = System.getProperty("appEnv", environment);

		Environment env = new Environment();
		InputStream inputStream = env.getResourceAsStream(appEnv);
		Properties props = new Properties();
		props.load(inputStream);
		appurl = Environment.getProperties().getProperty("appurl");
		inputStream.close();

		return props;
	}


	public static void setEnvDetails() {

		try {
		appurl = Environment.getProperties().getProperty("appurl");

		}
		catch(Exception e){
			//Handle errors for Class.forName
			e.printStackTrace();
		}

	}

	public String getResourceDirectory(){

		ClassLoader classLoader = getClass().getClassLoader();
		String path  = classLoader.getResource("TestEnv.properties").getPath();
		System.out.println("getResourceDirectory: " + path);
		return path;
	}

	public InputStream getResourceAsStream(String propFileName){

		ClassLoader classLoader = getClass().getClassLoader();
		InputStream inputStream = classLoader.getResourceAsStream(propFileName + ".properties");
		return inputStream;
	}
}

