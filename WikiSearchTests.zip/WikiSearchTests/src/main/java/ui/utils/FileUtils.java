package ui.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;

public class FileUtils {

    public static ArrayList ReadLangFile()
    {
        ArrayList fileLang = new ArrayList();
        File currentDirFile = new File(".");
        String helper = currentDirFile.getAbsolutePath();
        try {
            String currentDir = helper.substring(0, helper.length() - currentDirFile.getCanonicalPath().length());//
            String pathToFile = currentDir+"LangFile.csv";
            BufferedReader br = new BufferedReader(new FileReader(pathToFile));

            // read the first line from the text file
            String line = br.readLine();

            // loop until all lines are read
            while (line != null) {
                String[] attributes = line.split(",");
                line = br.readLine();
                fileLang.add(attributes[0]);
            }

        }
        catch(Exception ex) {
            System.out.println(ex);
        }

    return fileLang;
    }


}
