package ui.utils;

import org.openqa.selenium.WebDriver;
import ui.pages.BaseUIPage;

public class CommonFunctions extends BaseUIPage {

    public CommonFunctions(WebDriver driver) {
        super(driver);
    }

    public static void waitForSeconds(int seconds) {

        try {
            Thread.sleep(seconds*1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void waitForSecondsInIntervals(int seconds) {

        for (int i=0; i < seconds; i++) {

            try {
                Thread.sleep(1000);
                driver.getTitle();  //need to keep selenium grid session alive otherwise times out
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Waited " + seconds + " seconds");
    }
}
