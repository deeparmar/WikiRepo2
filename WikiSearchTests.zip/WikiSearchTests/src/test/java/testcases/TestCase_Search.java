package testcases;

import com.google.common.base.Verify;
import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import ui.pages.SearchPage;
import ui.pages.SearchResultPage;
import ui.testdata.StaticData;
import ui.utils.CommonFunctions;
import ui.utils.FileUtils;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class TestCase_Search extends BaseWebDriverTestCase {

    protected SearchPage searchPage;

    @Before
    public void Setup() {

        searchPage = new SearchPage(driver);
    }


    @Test
    public void WhenUserSearches_SearchResultsDisplayed() {

        //1 when user enter search text
        searchPage.setSearchTerm(StaticData.SEARCH_TERM);

        //2 and select search language
        searchPage.selectSearchLanguage("EN");

        //3 When user clicks on search
        SearchResultPage searchResultPage;
        searchResultPage =      searchPage.submitSearch();
        Assert.assertEquals("Greece",searchResultPage.pageHeading.getText());

        //4 Then Verify that search result page is available in other languages

        ArrayList lLang = new ArrayList();
        searchResultPage.scrollIntoView(searchResultPage.languages);

        for(int i = 1 ; i < searchResultPage.listLanguages.size() ; i++) {

         //   SearchResultsObject searchResultsObject = new SearchResultsObject();

            WebElement webElem = searchResultPage.listLanguages.get(i);
            lLang.add( webElem.getAttribute("lang"));


        }

        //Actual Lang List
        for(int j=0;j<lLang.size();j++) {
            System.out.println(lLang.get(j).toString());
        }

        //Expected Lang list
        Boolean b = lLang.equals(StaticData.LanguageList());
        if(b==true)
        {
            System.out.println("Search results page is available in :" +lLang.size()+ "Languages");
        }
        else
        {
            System.out.println("Some languages are missing for Search results page");
        }
    }


    @Test
    public void WhenUserSearches_SearchResultsDisplayedInOtherLanguage() {


        //1 when user enter search text
        searchPage.setSearchTerm(StaticData.SEARCH_TERM);

        //2 and select search language
        searchPage.selectSearchLanguage(StaticData.Default_Lang);

        //3 when user clicks on search
        SearchResultPage searchResultPage;
        searchResultPage =      searchPage.submitSearch();
        Assert.assertEquals("Greece",searchResultPage.pageHeading.getText());

        searchResultPage.scrollIntoView(searchResultPage.languages);

        //4. Then display search results in different language
        WebElement webElem= null;
        for(int i = 1 ; i < searchResultPage.listLanguages.size() ; i++) {
            webElem = searchResultPage.listLanguages.get(i);
            //  if( webElem.getText()=="Deutsch")
            if (webElem.getAttribute("href").equalsIgnoreCase(StaticData.DEU_URL))
            {
              webElem.click();
              break;
            }
        }

        //Now check if link to English page is present
        searchResultPage.scrollIntoView(searchResultPage.languages);
        boolean b= false;
        for(int i = 1 ; i < searchResultPage.listLanguages.size() ; i++) {
            webElem = searchResultPage.listLanguages.get(i);
            //  if( webElem.getText()=="Deutsch")
            if (webElem.getAttribute("href").contains(StaticData.EN_URL))
            {
                b= true;
                break;
            }
        }
        Assert.assertTrue(b);

    }

}