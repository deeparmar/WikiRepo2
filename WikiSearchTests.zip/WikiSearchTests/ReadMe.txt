1. Ensure that you have intellij Ide 2017.2.1 and Java 1.8 (1.8.0_111) installed
2. Download the project and open it in intellij IDE
3. Open intellijIde and launch the project - ensure that File > project structure > Project Settings > Modules >language leve is
set to 8 - Lambdas, type annonations
4. Ensure that  ensure that File > project structure > Project Settings > Project > Project language level is
set to 8 - Lambdas, type annonations
5. Select the Testrunner class under >Right click and run
6. Select TestCase_Search > Right click and Run
Note: This solution will only work on windows machine, it has not been implemented on MAC